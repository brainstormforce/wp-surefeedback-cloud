<?php
/**
 * Application - Main plugin application class
 *
 * @package SureFeedback
 * @author Anurag Singh <anurags@bsf.io>
 */

namespace SureFeedback;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Application class - Main plugin application
 */
class Application {

	/**
	 * Application version
	 *
	 * @var string
	 */
	const VERSION = SUREFEEDBACK_VERSION;

	/**
	 * Application instance
	 *
	 * @var static
	 */
	protected static $instance;

	/**
	 * Base path of the application
	 *
	 * @var string
	 */
	protected $basePath;

	/**
	 * Services registry
	 *
	 * @var array
	 */
	protected $services = array();

	/**
	 * Booted status
	 *
	 * @var bool
	 */
	protected $booted = false;

	/**
	 * Create a new application instance
	 *
	 * @param string|null $basePath Base path of the application.
	 */
	public function __construct( ?string $basePath = null ) {
		if ( $basePath ) {
			$this->basePath = rtrim( $basePath, '\/' );
		}

		static::$instance = $this;
	}

	/**
	 * Register a service
	 *
	 * @param string $name Service name.
	 * @param mixed  $service Service instance or callable.
	 * @return void
	 */
	public function register( $name, $service = null ): void {
		if ( is_object( $name ) && method_exists( $name, 'register' ) ) {
			// It's a service provider
			$name->register();
			if ( $this->booted && method_exists( $name, 'boot' ) ) {
				$name->boot();
			}
			return;
		}

		$this->services[ $name ] = $service;
	}

	/**
	 * Get a service
	 *
	 * @param string $name Service name.
	 * @return mixed
	 */
	public function make( string $name ) {
		if ( ! isset( $this->services[ $name ] ) ) {
			return null;
		}

		$service = $this->services[ $name ];

		if ( is_callable( $service ) ) {
			$this->services[ $name ] = $service( $this );
			return $this->services[ $name ];
		}

		return $service;
	}

	/**
	 * Boot the application
	 *
	 * @return void
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		// Register and initialize core services
		$this->bootServices();

		$this->booted = true;
	}

	/**
	 * Boot core services
	 *
	 * @return void
	 */
	protected function bootServices(): void {
		// Initialize CORS Service
		$this->register(
			'corsService',
			function () {
				return new \SureFeedback\Services\CorsService();
			}
		);
		$this->make( 'corsService' );

		// Register REST API routes first (must be done early)
		$this->registerApiRoutes();

		// Initialize AdminService only in admin area
		if ( is_admin() ) {
			$this->register(
				'adminService',
				function () {
					return new \SureFeedback\Services\AdminService();
				}
			);
			// Instantiate the service to trigger its hooks
			$this->make( 'adminService' );
		}

		// Initialize FrontendService for frontend
		if ( ! is_admin() ) {
			$this->register(
				'frontendService',
				function () {
					return new \SureFeedback\Services\FrontendService();
				}
			);
			// Instantiate the service to trigger its hooks
			$this->make( 'frontendService' );
		}

		// Initialize SecurityService (always needed)
		$this->register(
			'securityService',
			function () {
				return new \SureFeedback\Services\SecurityService();
			}
		);
	}



	/**
	 * Register REST API routes
	 *
	 * @return void
	 */
	protected function registerApiRoutes(): void {
		$router = new \SureFeedback\Http\Router();

		// Load the routes file
		$routesFile = $this->basePath . '/routes/api.php';
		if ( file_exists( $routesFile ) ) {
			require $routesFile;
		}

		// Register all routes with WordPress
		$router->register();
	}

	/**
	 * Get the application instance
	 *
	 * @return static
	 */
	public static function getInstance(): self {
		return static::$instance;
	}
}
